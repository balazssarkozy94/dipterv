#ifndef ADC_H
#define ADC_H

void initADC(void);

#endif
