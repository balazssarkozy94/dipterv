#ifndef DMA_H
#define DMA_H

#define ADC1_DR_ADDRESS     0x50000040

void initDMA(void);

#endif
