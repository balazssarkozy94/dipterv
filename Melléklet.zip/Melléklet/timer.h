#ifndef TIMER_H
#define TIMER_H

void initTimer17(void);
void delayus(uint32_t delay);

#endif
