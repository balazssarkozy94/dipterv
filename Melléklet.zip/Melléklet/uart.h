
#ifndef UART_H
#define UART_H

void initUART(void);
void sendDBG(char* msg, uint8_t size);

#endif
